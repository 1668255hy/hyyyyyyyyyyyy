-- 校园外卖平台数据库初始化脚本
CREATE DATABASE IF NOT EXISTS campus_takeout DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_takeout;

-- 用户表
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `phone` varchar(20) NOT NULL COMMENT '手机号',
  `password` varchar(100) NOT NULL COMMENT '密码加密存储',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `address` varchar(255) DEFAULT NULL COMMENT '默认收货地址',
  `role` int DEFAULT 1 COMMENT '角色:1普通用户 2商家 3骑手',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 商家表
CREATE TABLE `merchant` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '商家ID',
  `name` varchar(100) NOT NULL COMMENT '商家名称',
  `logo` varchar(255) DEFAULT NULL COMMENT '商家logo',
  `description` varchar(500) DEFAULT NULL COMMENT '商家简介',
  `address` varchar(255) NOT NULL COMMENT '商家地址',
  `phone` varchar(20) NOT NULL COMMENT '联系电话',
  `rating` decimal(2,1) DEFAULT 5.0 COMMENT '评分',
  `delivery_fee` decimal(3,1) DEFAULT 0.0 COMMENT '配送费',
  `min_price` decimal(5,1) DEFAULT 0.0 COMMENT '起送价',
  `status` int DEFAULT 1 COMMENT '营业状态:1营业 0打烊',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商家表';

-- 商品表
CREATE TABLE `product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `merchant_id` bigint NOT NULL COMMENT '所属商家ID',
  `name` varchar(100) NOT NULL COMMENT '商品名称',
  `image` varchar(255) DEFAULT NULL COMMENT '商品图片',
  `price` decimal(5,1) NOT NULL COMMENT '商品价格',
  `description` varchar(500) DEFAULT NULL COMMENT '商品描述',
  `sales` int DEFAULT 0 COMMENT '月销量',
  `status` int DEFAULT 1 COMMENT '上架状态:1上架 0下架',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_merchant` (`merchant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- 购物车表
CREATE TABLE `cart` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '用户ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `count` int NOT NULL DEFAULT 1 COMMENT '购买数量',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_product` (`user_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- 订单表
CREATE TABLE `order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(32) NOT NULL COMMENT '订单编号',
  `user_id` bigint NOT NULL COMMENT '下单用户ID',
  `merchant_id` bigint NOT NULL COMMENT '商家ID',
  `rider_id` bigint DEFAULT NULL COMMENT '配送骑手ID',
  `total_amount` decimal(6,1) NOT NULL COMMENT '订单总金额',
  `delivery_address` varchar(255) NOT NULL COMMENT '收货地址',
  `status` int DEFAULT 0 COMMENT '订单状态:0待接单 1已接单 2配送中 3已完成 4已取消',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 订单明细表
CREATE TABLE `order_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL COMMENT '关联订单ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `product_name` varchar(100) NOT NULL COMMENT '商品快照名称',
  `product_price` decimal(5,1) NOT NULL COMMENT '商品快照价格',
  `count` int NOT NULL COMMENT '购买数量',
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单明细表';

-- 骑手表
CREATE TABLE `rider` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL COMMENT '关联用户ID',
  `real_name` varchar(20) NOT NULL COMMENT '真实姓名',
  `phone` varchar(20) NOT NULL,
  `status` int DEFAULT 1 COMMENT '在线状态:1在线 0休息',
  `current_lng` decimal(10,6) DEFAULT NULL COMMENT '当前经度',
  `current_lat` decimal(10,6) DEFAULT NULL COMMENT '当前纬度',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='骑手表';

-- 插入测试数据
INSERT INTO `user` (`phone`, `password`, `nickname`, `role`) VALUES
('13800138000', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '测试同学', 1),
('13900139000', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '美食城商家', 2),
('13700137000', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '张骑手', 3);

INSERT INTO `merchant` (`name`, `description`, `address`, `phone`, `rating`, `delivery_fee`, `min_price`) VALUES
('一食堂麻辣香锅', '正宗川味麻辣香锅，食材新鲜现选现炒', '第一食堂二楼201档口', '0731-88888881', 4.8, 2.0, 15.0),
('二食堂黄焖鸡米饭', '传统鲁菜黄焖鸡，汤汁拌饭绝佳', '第二食堂一楼105档口', '0731-88888882', 4.6, 1.5, 12.0),
('后街奶茶铺', '鲜萃果茶、手工奶茶，下单送小料', '校园后街出入口旁', '0731-88888883', 4.9, 3.0, 10.0);

INSERT INTO `product` (`merchant_id`, `name`, `price`, `description`, `sales`) VALUES
(1, '经典麻辣香锅单人餐', 18.8, '含8种配菜+米饭，微辣/中辣/特辣可选', 326),
(1, '荤素搭配双人餐', 36.8, '含15种配菜+2份米饭，免费加面', 158),
(2, '招牌黄焖鸡小份', 13.8, '配米饭，可加土豆、香菇', 421),
(2, '黄焖排骨大份', 22.8, '足量排骨，两份米饭', 189),
(3, '招牌珍珠奶茶', 9.9, '锡兰红茶底，珍珠免费加', 562),
(3, '满杯百香果', 12.9, '新鲜百香果切片，清爽解腻', 387);
