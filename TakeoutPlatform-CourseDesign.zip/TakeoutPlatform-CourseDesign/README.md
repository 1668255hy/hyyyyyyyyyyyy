# 校园外卖配送平台 - 课程设计项目
基于Android Jetpack Compose + Spring Boot的全栈外卖平台实现，满足高校课程设计要求，代码可直接运行、上传开源仓库。

## 技术栈
### 客户端（Android）
- Kotlin 语言
- Jetpack Compose 声明式UI
- MVVM 架构
- Retrofit 网络请求
- Navigation 页面导航
- Material3 设计规范

### 服务端（Backend）
- Spring Boot 3.x
- MyBatis-Plus ORM框架
- MySQL 8.0 数据库
- RESTful API 接口规范
- 全局跨域配置

## 项目目录结构
```
TakeoutPlatform-CourseDesign/
├── android-app/                # Android客户端工程
│   └── app/src/main/
│       ├── java/com/campus/takeout/
│       │   ├── MainActivity.kt  # 应用入口
│       │   ├── ui/              # Compose页面与主题
│       │   ├── network/         # Retrofit网络层
│       │   └── model/            # 数据模型
│       └── AndroidManifest.xml
├── backend-server/              # Spring Boot后端工程
│   └── src/main/
│       ├── java/com/campus/takeout/
│       │   ├── controller/       # 业务接口层
│       │   ├── service/          # 业务逻辑层
│       │   ├── mapper/           # 数据访问层
│       │   ├── entity/           # 数据库实体
│       │   ├── config/           # 全局配置
│       │   └── common/           # 通用工具类
│       └── resources/application.yml
├── sql/
│   └── init.sql                 # 数据库初始化脚本
└── README.md
```

## 运行步骤
1. 数据库初始化：执行 `sql/init.sql` 创建库表并插入测试数据
2. 后端启动：导入 `backend-server` 到IDEA，修改数据库账号密码后启动服务，端口8080
3. 客户端启动：导入 `android-app` 到Android Studio，连接模拟器后运行应用
4. 测试账号：手机号 13800138000，密码 123456

## 已实现核心功能
- [x] 用户手机号登录鉴权
- [x] 首页商家列表展示（按评分排序）
- [x] 商家详情与商品列表浏览
- [x] 购物车选品与数量调整
- [x] 订单提交与状态流转（待接单→配送中→已完成）
- [x] 骑手端订单抢单与位置上报
