package com.campus.takeout.network

import com.campus.takeout.model.Merchant
import com.campus.takeout.model.Product
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @POST("api/auth/login")
    suspend fun login(@Body params: Map<String, String>): Map<String, Any>

    @GET("api/merchant/list")
    suspend fun getMerchantList(): List<Merchant>

    @GET("api/product/list")
    suspend fun getProductList(@Query("merchantId") merchantId: Long): List<Product>
}
