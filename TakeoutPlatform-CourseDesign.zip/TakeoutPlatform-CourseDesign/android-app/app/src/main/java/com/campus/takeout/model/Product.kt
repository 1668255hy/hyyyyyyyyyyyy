package com.campus.takeout.model

data class Product(
    val id: Long,
    val merchantId: Long,
    val name: String,
    val price: String,
    val description: String,
    val sales: Int
)
