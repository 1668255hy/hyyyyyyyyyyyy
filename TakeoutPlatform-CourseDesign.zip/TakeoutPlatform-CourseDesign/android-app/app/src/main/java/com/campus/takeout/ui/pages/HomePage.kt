package com.campus.takeout.ui.pages

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.campus.takeout.model.Merchant

@Composable
fun HomePage(navController: NavController) {
    val mockMerchantList = listOf(
        Merchant(1, "一食堂麻辣香锅", "正宗川味麻辣香锅，食材新鲜现选现炒", "4.8", "2.0", "15.0"),
        Merchant(2, "二食堂黄焖鸡米饭", "传统鲁菜黄焖鸡，汤汁拌饭绝佳", "4.6", "1.5", "12.0"),
        Merchant(3, "后街奶茶铺", "鲜萃果茶、手工奶茶，下单送小料", "4.9", "3.0", "10.0")
    )

    Scaffold(topBar = {
        TopAppBar(title = { Text("校园外卖") })
    }) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp)) {
            items(mockMerchantList) { merchant ->
                MerchantCard(merchant)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun MerchantCard(merchant: Merchant) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(merchant.name, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Text(merchant.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("评分：${merchant.rating}", style = MaterialTheme.typography.bodySmall)
                Text("起送：¥${merchant.minPrice}", style = MaterialTheme.typography.bodySmall)
                Text("配送费：¥${merchant.deliveryFee}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
