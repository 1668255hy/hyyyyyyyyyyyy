package com.campus.takeout.model

data class Merchant(
    val id: Long,
    val name: String,
    val description: String,
    val rating: String,
    val deliveryFee: String,
    val minPrice: String
)
