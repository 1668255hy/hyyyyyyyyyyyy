package com.campus.takeout.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.takeout.common.Result;
import com.campus.takeout.entity.Product;
import com.campus.takeout.mapper.ProductMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/product")
@RequiredArgsConstructor
public class ProductController {
    private final ProductMapper productMapper;

    @GetMapping("/list")
    public Result<List<Product>> listByMerchant(@RequestParam Long merchantId) {
        List<Product> list = productMapper.selectList(new LambdaQueryWrapper<Product>()
                .eq(Product::getMerchantId, merchantId)
                .eq(Product::getStatus, 1)
                .orderByDesc(Product::getSales));
        return Result.success(list);
    }
}
