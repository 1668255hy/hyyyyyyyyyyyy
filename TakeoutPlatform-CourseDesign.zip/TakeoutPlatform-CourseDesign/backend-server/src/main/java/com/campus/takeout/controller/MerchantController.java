package com.campus.takeout.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.takeout.common.Result;
import com.campus.takeout.entity.Merchant;
import com.campus.takeout.mapper.MerchantMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/merchant")
@RequiredArgsConstructor
public class MerchantController {
    private final MerchantMapper merchantMapper;

    @GetMapping("/list")
    public Result<List<Merchant>> list() {
        List<Merchant> list = merchantMapper.selectList(new LambdaQueryWrapper<Merchant>()
                .eq(Merchant::getStatus, 1)
                .orderByDesc(Merchant::getRating));
        return Result.success(list);
    }

    @GetMapping("/{id}")
    public Result<Merchant> detail(@PathVariable Long id) {
        return Result.success(merchantMapper.selectById(id));
    }
}
