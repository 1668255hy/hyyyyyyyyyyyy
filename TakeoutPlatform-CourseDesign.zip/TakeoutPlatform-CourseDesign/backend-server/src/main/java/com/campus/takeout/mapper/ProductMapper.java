package com.campus.takeout.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.takeout.entity.Product;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductMapper extends BaseMapper<Product> {
}
