package com.campus.takeout.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.takeout.common.Result;
import com.campus.takeout.entity.User;
import com.campus.takeout.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UserMapper userMapper;

    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody User loginUser) {
        User user = userMapper.selectOne(new LambdaQueryWrapper<User>()
                .eq(User::getPhone, loginUser.getPhone())
                .eq(User::getPassword, loginUser.getPassword()));
        if (user == null) {
            return Result.error("手机号或密码错误");
        }
        Map<String, Object> data = new HashMap<>();
        data.put("token", UUID.randomUUID().toString());
        data.put("userInfo", user);
        return Result.success(data);
    }
}
