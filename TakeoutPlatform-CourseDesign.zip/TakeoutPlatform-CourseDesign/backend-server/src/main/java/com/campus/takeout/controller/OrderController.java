package com.campus.takeout.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.takeout.common.Result;
import com.campus.takeout.entity.Orders;
import com.campus.takeout.mapper.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/order")
@RequiredArgsConstructor
public class OrderController {
    private final OrderMapper orderMapper;

    @PostMapping("/create")
    public Result<Orders> create(@RequestBody Orders order) {
        order.setOrderNo(DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now()) +
                UUID.randomUUID().toString().substring(0,4));
        order.setStatus(0);
        orderMapper.insert(order);
        return Result.success(order);
    }

    @GetMapping("/list/{userId}")
    public Result<List<Orders>> userOrders(@PathVariable Long userId) {
        List<Orders> list = orderMapper.selectList(new LambdaQueryWrapper<Orders>()
                .eq(Orders::getUserId, userId)
                .orderByDesc(Orders::getCreateTime));
        return Result.success(list);
    }
}
