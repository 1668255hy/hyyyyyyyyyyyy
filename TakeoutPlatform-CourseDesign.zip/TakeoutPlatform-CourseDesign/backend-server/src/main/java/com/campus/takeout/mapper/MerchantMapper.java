package com.campus.takeout.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.takeout.entity.Merchant;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MerchantMapper extends BaseMapper<Merchant> {
}
